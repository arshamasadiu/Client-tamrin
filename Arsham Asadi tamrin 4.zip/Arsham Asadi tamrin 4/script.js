var video = document.querySelector('video');
var previousBtn = document.querySelector('.previous');
var nextBtn = document.querySelector('.next');
var restBtn = document.querySelector('.rest');


function jolo() {
    video.currentTime +=5;
}
function aghab() {
    video.currentTime -=5;
}
function rest() {
            video.currentTime = 0;
        }

previousBtn.addEventListener('click',aghab);
nextBtn.addEventListener('click',jolo);
restBtn.addEventListener('click',rest);
